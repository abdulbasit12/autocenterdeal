import React from 'react'

function Header() {
  return (
    <div>Dealers Auto Center</div>
  )
}

export default Header